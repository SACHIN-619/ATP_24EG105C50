### Steps to create backend


1.Generate packange.json file
       npm init -y   (change description,type,etc)
2.Create HTTP server
     -  Install & Import express module
           npm install express
     - Import express

       To update the esrver automatically [npm install -g nodemon] and run [nodemon server.js]
