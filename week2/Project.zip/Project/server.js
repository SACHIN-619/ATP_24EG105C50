//create HTTP  server
import exp from 'express'
const app = exp()  // it creates espresss expression and app is name to specially identify 


//set a port number
const port = 3000
//assign port number to HTTP sever
app.listen(port, ()=> console.log(`server listening port ${port} ...`))

//Create API(RESTapi - Repressentational Strate Transfer)
     //Route to handle GET req of Client
    app.get('/users',(req,res)=>{
        //send res to client
        res.json({message:"This is message: Hello"})
    })
    //Route to handle POST req of Client
    app.post('/users',(req,res)=>{
           res.json({message:"This is message: hello"})
    })
    
     //Route to handle PUT req of Client
     app.put('/users',(req,res)=>{
        res.json({message:"This is message"})
     })

     //Route to handle DELETE req of Client
     app.delete('/users',(req,res)=>{
        res.json({message:"This is message"})
     })